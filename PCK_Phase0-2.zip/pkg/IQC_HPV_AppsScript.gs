/**
 * ═══════════════════════════════════════════════════════════════════
 *  IQC cobas® HPV — Google Apps Script  (doPost + doGet)   v2
 *  ห้องปฏิบัติการเทคนิคการแพทย์ · โรงพยาบาลพระจอมเกล้า เพชรบุรี
 *  ───────────────────────────────────────────────────────────────
 *  doPost : รับข้อมูลจากฟอร์ม IQC_cobas_HPV.html
 *  doGet  : คืนข้อมูล JSON ให้ HPV_IQC_Dashboard.html ดึงแบบ real-time
 *
 *  ⚠️ โครงสร้าง Sheet ที่โค้ดนี้ยึด (ตรวจสอบจากไฟล์จริงแล้ว):
 *      แถว 1  = หัวข้อกลุ่ม (merge + สี)  เช่น "Run Information"
 *      แถว 2  = ชื่อคอลัมน์จริง           เช่น "วันที่บันทึก"
 *      แถว 3+ = ข้อมูล
 *
 *  ✅ ไม่แตะแถว 1–2  ✅ ไม่เปลี่ยนจำนวนคอลัมน์  ✅ ข้อมูลเก่าไม่เลื่อน
 * ═══════════════════════════════════════════════════════════════════
 */

// ─────────────────────────────────────────────────────────────────
//  CONFIG
// ─────────────────────────────────────────────────────────────────
const SHEET_ID   = '1mXRv-anNhDXtW7nnHvQqcEmPqdcbiSoxNZUkKyuq1Wk';
const SHEET_NAME = '';    // '' = แท็บแรก | ใส่ชื่อแท็บถ้ามีหลายแท็บ
const TZ         = 'Asia/Bangkok';
const CACHE_SEC  = 30;

const HEADER_ROW = 2;     // ← แถวที่มี "ชื่อคอลัมน์" จริง
const DATA_ROW   = 3;     // ← แถวแรกของข้อมูล

/** ชื่อหัวคอลัมน์ (แถว 2) → key ที่ dashboard ใช้ */
const KEYMAP = {
  'วันที่บันทึก':'date',          'เวลา':'time',            'ผู้บันทึก':'operator',
  'Run no./Batch':'run_no',       'Test Type':'test_type',
  'อุณหภูมิ(°C)':'temp',          'ความชื้น(%RH)':'humidity',
  'Lot Pos Control':'lot_pos',    'EXP Pos Control':'exp_pos',
  'Lot Neg Control':'lot_neg',    'EXP Neg Control':'exp_neg',
  'Lot Reagent Kit':'lot_reagent','EXP Reagent Kit':'exp_reagent',
  'PC T1 Other HR (Ct)':'pc_t1',  'PC T1 ผล':'pc_t1_result',
  'PC T2 HPV16 (Ct)':'pc_t2',     'PC T2 ผล':'pc_t2_result',
  'PC T3 HPV18 (Ct)':'pc_t3',     'PC T3 ผล':'pc_t3_result',
  'PC Overall':'pc_overall',
  'NC T1 Other HR':'nc_t1',       'NC T1 ผล':'nc_t1_result',
  'NC T2 HPV16':'nc_t2',          'NC T2 ผล':'nc_t2_result',
  'NC T3 HPV18':'nc_t3',          'NC T3 ผล':'nc_t3_result',
  'NC Overall':'nc_overall',
  'Batch Result':'batch',
  'หมายเหตุ':'remark',            'ผู้ตรวจสอบ':'verifier',  'วันที่ตรวจสอบ':'verify_date',
  'Timestamp':'timestamp'
};

const NUMERIC_KEYS = ['temp','humidity','pc_t1','pc_t2','pc_t3'];

// ─────────────────────────────────────────────────────────────────
//  HELPERS
// ─────────────────────────────────────────────────────────────────
function getSheet_() {
  const ss = SpreadsheetApp.openById(SHEET_ID);
  return (SHEET_NAME && ss.getSheetByName(SHEET_NAME)) || ss.getSheets()[0];
}

/** ตัวนับเวอร์ชันข้อมูล — ใช้ล้าง cache อัตโนมัติเมื่อมีการบันทึกใหม่ */
function gen_() {
  return PropertiesService.getScriptProperties().getProperty('gen') || '0';
}
function bumpGen_() {
  const p = PropertiesService.getScriptProperties();
  p.setProperty('gen', String(Number(gen_()) + 1));
}

/** ตอบกลับ JSON — รองรับ JSONP ถ้าส่ง ?callback= มา */
function reply_(obj, callback) {
  const json = JSON.stringify(obj);
  if (callback && /^[A-Za-z_$][\w$]*$/.test(callback)) {
    return ContentService.createTextOutput(callback + '(' + json + ');')
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(json)
    .setMimeType(ContentService.MimeType.JSON);
}

/** ล้างช่องว่าง/ตัวขึ้นบรรทัดใหม่ออกจากชื่อหัวคอลัมน์ */
function clean_(s) {
  return String(s).replace(/[\r\n ]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function norm_(key, v) {
  if (v === '' || v === null || v === undefined) return null;
  if (v instanceof Date) {
    if (key === 'time') return Utilities.formatDate(v, TZ, 'HH:mm');
    return Utilities.formatDate(v, TZ, 'yyyy-MM-dd');
  }
  if (NUMERIC_KEYS.indexOf(key) >= 0) {
    const n = parseFloat(String(v).replace(/,/g, ''));
    return isNaN(n) ? null : n;
  }
  return String(v).trim();
}

function dupKey_(r) {
  return [r.date, r.time, r.pc_t1, r.pc_t2, r.pc_t3].join('|');
}

// ─────────────────────────────────────────────────────────────────
//  doGet
//    ?action=iqc                        ข้อมูลทั้งหมด
//    ?action=iqc&from=2026-01-01&to=... กรองช่วงวันที่
//    ?action=iqc&test=HPV               กรอง Test Type
//    ?action=meta                       เช็คจำนวนแถว/เวลาอัปเดต (เบามาก)
//    ?action=headers                    ตรวจว่าแมปหัวคอลัมน์ครบไหม
//    &nocache=1                         ข้าม cache
//    &callback=fn                       JSONP
// ─────────────────────────────────────────────────────────────────
function doGet(e) {
  const p  = (e && e.parameter) || {};
  const cb = p.callback;

  try {
    const action = p.action || 'iqc';
    const cache  = CacheService.getScriptCache();
    const ckey   = ['iqc', gen_(), action, p.from||'', p.to||'', p.test||''].join('_');

    if (!p.nocache) {
      const hit = cache.get(ckey);
      if (hit) return reply_(JSON.parse(hit), cb);
    }

    const sh   = getSheet_();
    const last = sh.getLastRow();
    const now  = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd'T'HH:mm:ssXXX");

    if (last < DATA_ROW) {
      return reply_({ ok:true, count:0, rows:[], duplicates:[], updated:now }, cb);
    }

    // อ่านตั้งแต่แถวหัวคอลัมน์ (แถว 2) ลงมา — ข้ามแถว 1 ที่เป็นหัวข้อกลุ่ม
    const values = sh.getRange(HEADER_ROW, 1, last - HEADER_ROW + 1, sh.getLastColumn()).getValues();
    const head   = values[0].map(clean_);

    // แมปชื่อหัวคอลัมน์ → key  (อ่านตามชื่อ ไม่ใช่ตำแหน่ง → สลับคอลัมน์ก็ยังอ่านถูก)
    const idx = {}, unmapped = [];
    head.forEach(function (h, i) {
      if (!h) return;
      if (KEYMAP[h]) idx[KEYMAP[h]] = i;
      else unmapped.push('[' + (i + 1) + '] ' + h);
    });

    if (action === 'headers') {
      return reply_({ ok:true, headerRow:HEADER_ROW, columns:head.length,
                      mapped:Object.keys(idx).length, unmapped:unmapped, headers:head }, cb);
    }
    if (action === 'meta') {
      return reply_({ ok:true, count:last - DATA_ROW + 1, updated:now }, cb);
    }

    const seen = {}, dups = [];
    let rows = [];

    for (let r = 1; r < values.length; r++) {          // r=1 คือแถว 3 ของ Sheet
      const row = values[r];
      if (row.every(function (c) { return c === '' || c === null; })) continue;

      const o = { _row: HEADER_ROW + r };
      Object.keys(idx).forEach(function (k) { o[k] = norm_(k, row[idx[k]]); });
      if (!o.date) continue;

      const k = dupKey_(o);
      o.duplicate = !!seen[k];
      if (seen[k]) dups.push({ row:o._row, run_no:o.run_no, sameAs:seen[k] });
      else seen[k] = o._row;

      rows.push(o);
    }

    if (p.from) rows = rows.filter(function (x) { return x.date >= p.from; });
    if (p.to)   rows = rows.filter(function (x) { return x.date <= p.to;   });
    if (p.test) rows = rows.filter(function (x) {
      return !x.test_type || String(x.test_type).toUpperCase().indexOf(p.test.toUpperCase()) >= 0;
    });

    rows.sort(function (a, b) {
      return (a.date + ' ' + (a.time || '')).localeCompare(b.date + ' ' + (b.time || ''));
    });

    const out = {
      ok: true,
      sheet: sh.getName(),
      count: rows.length,
      duplicates: dups,
      unmapped: unmapped,          // ถ้าไม่ว่าง = มีคอลัมน์ที่แมปไม่ได้ ต้องแก้ KEYMAP
      updated: now,
      rows: rows
    };

    try { cache.put(ckey, JSON.stringify(out), CACHE_SEC); } catch (ignore) {}
    return reply_(out, cb);

  } catch (err) {
    return reply_({ ok:false, error: String((err && err.message) || err) }, cb);
  }
}

// ─────────────────────────────────────────────────────────────────
//  doPost — รับข้อมูลจากฟอร์ม
// ─────────────────────────────────────────────────────────────────
function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);                      // กันสองคนกดบันทึกพร้อมกัน

    const sheet = getSheet_();
    const data  = JSON.parse(e.postData.contents);

    // ไม่สร้างหัวตารางเอง — หัวตาราง 2 ชั้นออกแบบไว้แล้ว ห้ามเขียนทับ
    if (sheet.getLastRow() < HEADER_ROW) {
      return reply_({ status:'error',
        message:'Sheet ยังไม่มีหัวตาราง 2 แถว กรุณาใช้ setupNewSheet() สร้างจากแท็บเดิมก่อน' });
    }

    const dupRow = findDuplicate_(sheet, data);
    if (dupRow) {
      return reply_({ status:'duplicate', row:dupRow,
        message:'ข้อมูลชุดนี้ถูกบันทึกไว้แล้วที่แถว ' + dupRow });
    }

    sheet.appendRow([
      data.date, data.time, data.recorder, data.batchNo, data.testType,
      data.temp, data.humidity,
      data.lotPC, data.expPC,
      data.lotNC, data.expNC,
      data.lotKit, data.expKit,
      data.pcT1Ct, data.pcT1Result,
      data.pcT2Ct, data.pcT2Result,
      data.pcT3Ct, data.pcT3Result,
      data.pcOverall,
      data.ncT1Val, data.ncT1Result,
      data.ncT2Val, data.ncT2Result,
      data.ncT3Val, data.ncT3Result,
      data.ncOverall,
      data.batchResult,
      data.remark, data.verifier, data.verifyDate,
      Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss')
    ]);

    bumpGen_();                                // ล้าง cache ให้ dashboard เห็นทันที
    return reply_({ status:'success', row: sheet.getLastRow() });

  } catch (err) {
    return reply_({ status:'error', message: String((err && err.message) || err) });
  } finally {
    try { lock.releaseLock(); } catch (ignore) {}
  }
}

/** หาแถวซ้ำใน 20 แถวล่าสุด — คืนเลขแถว, ไม่ซ้ำคืน 0 */
function findDuplicate_(sheet, data) {
  const last = sheet.getLastRow();
  if (last < DATA_ROW) return 0;
  const avail = last - DATA_ROW + 1;
  const n     = Math.min(20, avail);
  const start = last - n + 1;
  const vals  = sheet.getRange(start, 1, n, 19).getValues();
  const key   = [data.date, data.time, data.pcT1Ct, data.pcT2Ct, data.pcT3Ct].join('|');

  for (let i = 0; i < vals.length; i++) {
    const v = vals[i];
    const d = v[0] instanceof Date ? Utilities.formatDate(v[0], TZ, 'yyyy-MM-dd') : String(v[0]).trim();
    const t = v[1] instanceof Date ? Utilities.formatDate(v[1], TZ, 'HH:mm')      : String(v[1]).trim();
    const k = [d, t, String(v[13]).trim(), String(v[15]).trim(), String(v[17]).trim()].join('|');
    if (k === key) return start + i;
  }
  return 0;
}

// ─────────────────────────────────────────────────────────────────
//  UTILITIES — รันมือจาก Editor
// ─────────────────────────────────────────────────────────────────

/** ตรวจว่าแมปหัวคอลัมน์ครบทุกช่องไหม — รันอันนี้ก่อน deploy */
function testHeaders() {
  const o = JSON.parse(doGet({ parameter:{ action:'headers', nocache:'1' } }).getContent());
  Logger.log('คอลัมน์ทั้งหมด : %s', o.columns);
  Logger.log('แมปได้         : %s', o.mapped);
  Logger.log('แมปไม่ได้      : %s', o.unmapped.length ? o.unmapped.join(' , ') : '— ครบทุกคอลัมน์ ✅');
}

/** ทดสอบอ่านข้อมูลจริง */
function testGet() {
  const o = JSON.parse(doGet({ parameter:{ action:'iqc', nocache:'1' } }).getContent());
  Logger.log('ok=%s | sheet="%s" | %s แถว | ซ้ำ %s คู่', o.ok, o.sheet, o.count, o.duplicates.length);
  if (o.unmapped && o.unmapped.length) Logger.log('⚠️ คอลัมน์ที่แมปไม่ได้ : %s', o.unmapped.join(' , '));
  o.duplicates.forEach(function (d) {
    Logger.log('   แถว %s (run %s) ซ้ำกับแถว %s', d.row, d.run_no, d.sameAs);
  });
  Logger.log('แถวแรก  : %s', JSON.stringify(o.rows[0]));
  Logger.log('แถวล่าสุด: %s', JSON.stringify(o.rows[o.rows.length - 1]));
}

/** ส่งออกข้อมูลเป็น JSON ก้อนเดียว (ก๊อปจาก Log ไปใช้ต่อได้) */
function exportJSON() {
  const o = JSON.parse(doGet({ parameter:{ action:'iqc', nocache:'1' } }).getContent());
  const slim = o.rows.map(function (r) {
    return { date:r.date, time:r.time, operator:r.operator, run_no:r.run_no,
             lot_pos:r.lot_pos, lot_neg:r.lot_neg, lot_reagent:r.lot_reagent,
             temp:r.temp, pc_t1:r.pc_t1, pc_t2:r.pc_t2, pc_t3:r.pc_t3,
             batch:r.batch, duplicate:r.duplicate };
  });
  Logger.log(JSON.stringify(slim));
}

/** สร้างแท็บใหม่สำหรับปีถัดไป โดยก๊อปหัวตาราง 2 แถว (พร้อม merge/สี) จากแท็บปัจจุบัน */
function setupNewSheet() {
  const NEW_NAME = 'IQC_2570';               // ← แก้ชื่อก่อนรัน
  const ss  = SpreadsheetApp.openById(SHEET_ID);
  const src = getSheet_();
  if (ss.getSheetByName(NEW_NAME)) { Logger.log('มีแท็บ "%s" อยู่แล้ว', NEW_NAME); return; }

  const sh = src.copyTo(ss).setName(NEW_NAME);
  const last = sh.getLastRow();
  if (last >= DATA_ROW) sh.deleteRows(DATA_ROW, last - DATA_ROW + 1);   // ลบเฉพาะข้อมูล เก็บหัวตาราง
  Logger.log('สร้างแท็บ "%s" พร้อมหัวตาราง 2 แถวแล้ว', NEW_NAME);
}
