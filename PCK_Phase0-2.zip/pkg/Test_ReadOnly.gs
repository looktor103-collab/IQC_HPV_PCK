/**
 * ═══════════════════════════════════════════════════════════════
 *  Test_ReadOnly.gs — สคริปต์ตรวจสอบข้อมูล IQC (อ่านอย่างเดียว)
 *  ───────────────────────────────────────────────────────────────
 *  ✅ ปลอดภัย 100% : อ่านอย่างเดียว ไม่เขียน ไม่ลบ ไม่แก้อะไรใน Sheet
 *  ✅ ไม่ต้อง Deploy : กด Run ในหน้า Editor ได้เลย
 *  ✅ ไม่กระทบ doPost เดิม : เป็นไฟล์แยก ฟอร์มยังทำงานปกติ
 *
 *  วิธีใช้ : เลือกฟังก์ชัน checkIQC จาก dropdown ด้านบน → กด Run
 *           แล้วดูผลที่ช่อง "บันทึกการดำเนินการ / Execution log" ด้านล่าง
 * ═══════════════════════════════════════════════════════════════
 */

function checkIQC() {
  const SHEET_ID = '1mXRv-anNhDXtW7nnHvQqcEmPqdcbiSoxNZUkKyuq1Wk';
  const TZ = 'Asia/Bangkok';

  const ss = SpreadsheetApp.openById(SHEET_ID);
  Logger.log('════════════════════════════════════════════');
  Logger.log('ไฟล์ Sheet : %s', ss.getName());

  // ── มีกี่แท็บ อะไรบ้าง ──
  const tabs = ss.getSheets().map(function (s) {
    return s.getName() + ' (' + s.getLastRow() + ' แถว)';
  });
  Logger.log('แท็บทั้งหมด (%s) : %s', tabs.length, tabs.join(' | '));

  const sh = ss.getSheets()[0];        // แท็บแรก = ที่ doPost เขียนลง
  Logger.log('กำลังอ่านแท็บ : "%s"', sh.getName());

  const lastRow = sh.getLastRow();
  const lastCol = sh.getLastColumn();
  Logger.log('ขนาดข้อมูล : %s แถว × %s คอลัมน์', lastRow, lastCol);

  if (lastRow < 2) {
    Logger.log('⚠️ ยังไม่มีข้อมูล (มีแค่หัวตารางหรือว่างเปล่า)');
    return;
  }

  const values = sh.getRange(1, 1, lastRow, lastCol).getValues();
  const head = values[0];

  Logger.log('════════════════════════════════════════════');
  Logger.log('หัวตาราง %s คอลัมน์ :', head.length);
  Logger.log('%s', head.map(function (h, i) {
    return '[' + (i + 1) + '] ' + h;
  }).join('  '));

  // ── แปลงค่าให้เป็นข้อความอ่านง่าย ──
  function txt(v, fmt) {
    if (v === '' || v === null || v === undefined) return '';
    if (v instanceof Date) return Utilities.formatDate(v, TZ, fmt || 'yyyy-MM-dd');
    return String(v).trim();
  }

  const rows = [];
  for (let r = 1; r < values.length; r++) {
    const v = values[r];
    if (v.every(function (c) { return c === '' || c === null; })) continue;

    rows.push({
      row: r + 1,
      date: txt(v[0]),                    // A  วันที่บันทึก
      time: txt(v[1], 'HH:mm'),           // B  เวลา
      operator: txt(v[2]),                // C  ผู้บันทึก
      run: txt(v[3]),                     // D  Run no.
      lotPos: txt(v[7]),                  // H  Lot Pos Control
      expKit: txt(v[12]),                 // M  EXP Reagent Kit
      t1: txt(v[13]),                     // N  PC T1 Ct
      t2: txt(v[15]),                     // P  PC T2 Ct
      t3: txt(v[17]),                     // R  PC T3 Ct
      batch: txt(v[27]),                  // AB Batch Result
      verifier: txt(v[29]),               // AD ผู้ตรวจสอบ
      verifyDate: txt(v[30])              // AE วันที่ตรวจสอบ
    });
  }

  Logger.log('════════════════════════════════════════════');
  Logger.log('📊 จำนวนแถวข้อมูลจริง : %s แถว', rows.length);

  // ── หาแถวซ้ำ : วันที่ + เวลา + Ct ทั้ง 3 ตัว เหมือนกัน ──
  const seen = {}, dups = [];
  rows.forEach(function (r) {
    const key = [r.date, r.time, r.t1, r.t2, r.t3].join('|');
    if (seen[key]) dups.push({ a: seen[key], b: r });
    else seen[key] = r;
  });

  Logger.log('🔁 แถวที่ซ้ำ : %s คู่', dups.length);
  dups.forEach(function (d) {
    Logger.log('   แถว %s (%s / %s) ซ้ำกับ แถว %s (%s / %s)  →  %s %s  Ct=%s,%s,%s',
      d.b.row, d.b.operator, d.b.run,
      d.a.row, d.a.operator, d.a.run,
      d.b.date, d.b.time, d.b.t1, d.b.t2, d.b.t3);
  });

  // ── ช่วงวันที่ ──
  const dates = rows.map(function (r) { return r.date; })
                    .filter(String).sort();
  Logger.log('════════════════════════════════════════════');
  Logger.log('📅 ช่วงข้อมูล : %s  ถึง  %s', dates[0], dates[dates.length - 1]);

  // ── ตรวจคอลัมน์ที่สงสัยว่าบั๊ก ──
  function countFilled(key) {
    return rows.filter(function (r) { return r[key] !== ''; }).length;
  }
  Logger.log('════════════════════════════════════════════');
  Logger.log('🔍 ตรวจคอลัมน์ที่สงสัยว่ามีบั๊ก :');
  Logger.log('   EXP Reagent Kit  มีค่า %s / %s แถว   %s',
    countFilled('expKit'), rows.length,
    countFilled('expKit') === 0 ? '❌ ว่างทั้งหมด = ยืนยันบั๊ก' : '');
  Logger.log('   ผู้ตรวจสอบ        มีค่า %s / %s แถว', countFilled('verifier'), rows.length);
  Logger.log('   วันที่ตรวจสอบ     มีค่า %s / %s แถว', countFilled('verifyDate'), rows.length);

  // ── เทียบว่า "วันที่ตรวจสอบ" ไปเหมือน "EXP Pos Control" หรือไม่ ──
  let same = 0;
  for (let r = 1; r < values.length; r++) {
    const expPos = txt(values[r][8]);    // I  EXP Pos Control
    const vDate = txt(values[r][30]);    // AE วันที่ตรวจสอบ
    if (expPos && vDate && expPos === vDate) same++;
  }
  Logger.log('   "วันที่ตรวจสอบ" = "EXP Pos Control" จำนวน %s / %s แถว   %s',
    same, rows.length, same === rows.length && same > 0 ? '❌ ยืนยันบั๊ก' : '');

  // ── ตัวอย่างข้อมูล ──
  Logger.log('════════════════════════════════════════════');
  Logger.log('แถวแรกสุด  : %s', JSON.stringify(rows[0]));
  Logger.log('แถวล่าสุด  : %s', JSON.stringify(rows[rows.length - 1]));
  Logger.log('════════════════════════════════════════════');
  Logger.log('✅ สรุปสั้น : %s แถว | ซ้ำ %s คู่ | %s ถึง %s',
    rows.length, dups.length, dates[0], dates[dates.length - 1]);
}
