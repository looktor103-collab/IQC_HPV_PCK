# PCK — Phase 0 + 1  (ระบบดีไซน์ + เมนู)

## ไฟล์ในชุดนี้

    assets/pck.css          ระบบดีไซน์กลาง (token + component)
    assets/pck-compat.css   ชั้นแปลงชื่อตัวแปรเก่า สำหรับ 5 หน้าที่ใช้ชื่อคนละชุด
    assets/pck.js           app shell, เมนู, ธีม, client คุยกับ Google Sheet
    index.html              หน้าแรกใหม่
    IQC_HPV_AppsScript.gs   โค้ดวางใน Apps Script (doPost + doGet)
    Test_ReadOnly.gs        สคริปต์ตรวจข้อมูล อ่านอย่างเดียว

## วิธีติดตั้ง

1. แตกไฟล์ทับลงใน repo PCK ให้ตรงโครงสร้าง (จะได้โฟลเดอร์ `assets/` เพิ่มมา)
2. commit + push
3. รอ GitHub Pages deploy สัก 1–2 นาที

## ทดสอบบนเครื่องก่อน push

ต้อง serve จาก **โฟลเดอร์แม่** ของ PCK ไม่ใช่จากในโฟลเดอร์ PCK
เพราะ path เป็นแบบ `/PCK/assets/...`

    cd /path/ที่มีโฟลเดอร์/PCK/อยู่ข้างใน
    python3 -m http.server 8000
    # เปิด http://localhost:8000/PCK/index.html

## วิธีเอาไปใช้กับหน้าอื่น (Phase 3)

ใน `<head>` เพิ่ม

    <link rel="stylesheet" href="/PCK/assets/pck.css?v=1">

ก่อนปิด `</body>` เพิ่ม

    <script src="/PCK/assets/pck.js?v=1"></script>

แล้ว **ลบ `:root{...}` เดิมออกจาก `<style>` ในหน้านั้น**
(ถ้าไม่ลบ ตัวแปรในหน้าจะทับตัวแปรจากไฟล์กลาง แก้สีที่ไฟล์กลางแล้วจะไม่เปลี่ยน)

หน้าที่ใช้ชื่อตัวแปรคนละชุด ให้เพิ่ม compat ด้วย

    <link rel="stylesheet" href="/PCK/assets/pck-compat.css?v=1">

แล้วใส่ attribute ที่ `<html>` ตามตาราง

| หน้า | ใส่ที่ `<html>` |
|---|---|
| HPV_IQC_Dashboard.html, EQA_Summary.html, sop.html | `data-legacy="blue"` |
| IQC/IQC_HIV_VL_Generator.html | `data-legacy="hiv"` |
| maintanance/6800/FCP68030_2.html | `data-legacy="6800"` |
| EQA/covid/EQA_SARS-CoV-2_Dashboard.html | `data-legacy="covid"` |

หน้าที่ใช้ชุดสีเดียวกับ index.html เดิมอยู่แล้ว (IQC_cobas_HPV, inventory ฯลฯ)
**ไม่ต้องใส่ `data-legacy`** เพราะชื่อตัวแปรตรงกันหมด

## แก้ CSS แล้วไม่เปลี่ยน?

GitHub Pages cache ไฟล์ static ไว้ 10 นาที
แก้แล้วให้บวกเลขท้าย URL ทุกครั้ง: `?v=1` → `?v=2`

## ยังไม่ได้ทำในชุดนี้

- Phase 2: ต่อ HPV_IQC_Dashboard.html เข้ากับ doGet (รอผล testHeaders)
- Phase 3: ยกเครื่องหน้าที่เหลือ
- แก้บั๊ก 3 จุดใน IQC/IQC_cobas_HPV.html (expKit / verifier / verifyDate)

---

## Phase 2 (เพิ่มใหม่)

    IQC/HPV_IQC_Dashboard.html   dashboard ที่ดึงข้อมูลสดจาก Google Sheet

**Apps Script URL ที่ใช้อยู่** (ฝังไว้แล้วทั้งใน pck.js และฟอร์ม IQC):

    https://script.google.com/macros/s/AKfycbzcWl6q_L_TjJ34r8enZufcCAllMf8inHZvl4BuCv6U-0FaT2rKN0svvKKBe9sd1PBP/exec

ถ้าวันหลังต้อง deploy ใหม่จนได้ URL ใหม่ ต้องแก้ 2 จุด:

    assets/pck.js                  บรรทัด 175   (dashboard ดึงข้อมูล)
    IQC/IQC_cobas_HPV.html         บรรทัด 489   (ฟอร์มส่งข้อมูล)

### สิ่งที่ dashboard ทำ

- ดึงข้อมูลสดทุก 60 วินาที · หยุดเองเมื่อสลับแท็บ · ดึงทันทีเมื่อกลับมา
- สำรอง 3 ชั้น: สด -> cache ในเครื่อง -> ข้อมูลตัวอย่างที่ฝังไว้ (พร้อมป้ายเตือน)
- Westgard ครบ 6 กฎ: 1(3s) 1(2s) 2(2s) R(4s) 4(1s) 10x
- ตัดแถวซ้ำออกจากการคำนวณ แต่ยังแสดงในตาราง
- ตัดค่า Ct นอกช่วง 10-45 ออกจากสถิติ และทำเครื่องหมาย outlier
- เส้นแบ่งแนวตั้งตรงจุดเปลี่ยน Lot
- กรองตามช่วงวันที่และ Lot · ส่งออก CSV
